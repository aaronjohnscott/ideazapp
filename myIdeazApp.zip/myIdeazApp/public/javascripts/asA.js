const asAString = `with a super hero, at camp, in the woods, in a factory, in space, in highschool, in college, in business world, at senior center, plus sport, on a different planet, in future, in past, as spoof, with a competition, at sea, on a plane, in the south, with a homosexual, as a caper, plus a twin, plus a family member, fish out of water, fish back into water, with a split personality, with a wager, as a thriller, with a ransom`
const asAArr = asAString.split(", ")

module.exports = asAArr;